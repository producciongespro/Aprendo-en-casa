<?php

	$usuario = $_POST[usuario];
	$clave = $_POST[clave];
	
	
	echo ($usuario);

?>
